// secure-server.js (FINAL, HARDENED & CORRECTED)
require('dotenv').config(); // Load environment variables from .env file

const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const cookieParser = require('cookie-parser');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// --- Configuration from Environment Variables ---
const PORT = process.env.PORT || 1235;
const DB = new sqlite3.Database('./users.db');
const ACCESS_SECRET = process.env.ACCESS_TOKEN_SECRET;
const REFRESH_SECRET = process.env.REFRESH_TOKEN_SECRET;
const TOKEN_ISSUER = process.env.TOKEN_ISSUER;
const TOKEN_AUDIENCE = process.env.TOKEN_AUDIENCE;

// Ensure secrets and configs are loaded
if (!ACCESS_SECRET || !REFRESH_SECRET || !TOKEN_ISSUER || !TOKEN_AUDIENCE) {
  console.error("FATAL ERROR: JWT secrets or claims configuration are not defined in the .env file.");
  process.exit(1); // Exit if configuration is missing
}

// In-memory refresh token store (for lab purposes).
const refreshStore = new Map();

// --- Login Endpoint ---
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  DB.get("SELECT * FROM users WHERE username = ?", [username], (err, row) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!row || !bcrypt.compareSync(password, row.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const accessToken = jwt.sign(
      { sub: row.username, role: row.role },
      ACCESS_SECRET,
      {
        algorithm: 'HS256',
        expiresIn: '15m',
        issuer: TOKEN_ISSUER,
        audience: TOKEN_AUDIENCE
      }
    );

    const refreshTokenId = crypto.randomBytes(16).toString('hex');
    const refreshToken = jwt.sign(
      { sub: row.username, jti: refreshTokenId },
      REFRESH_SECRET,
      {
        algorithm: 'HS256',
        expiresIn: '7d',
        issuer: TOKEN_ISSUER,
        audience: TOKEN_AUDIENCE
      }
    );

    refreshStore.set(refreshTokenId, { username: row.username });

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: false,
      sameSite: 'Strict',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    return res.json({ accessToken });
  });
});

// --- Authentication Middleware ---
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided or malformed header' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = jwt.verify(token, ACCESS_SECRET, {
      algorithms: ['HS256'],
      issuer: TOKEN_ISSUER,
      audience: TOKEN_AUDIENCE
    });
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: `Invalid or expired token: ${err.message}` });
  }
}

// --- Protected Admin Route ---
app.get('/admin', authMiddleware, (req, res) => {
  if (req.user.role === 'admin') {
    return res.json({ secret: 'VERY SENSITIVE ADMIN DATA (SECURE)' });
  }
  return res.status(403).json({ error: 'Forbidden: Admin access required' });
});

// --- Secure Whoami Endpoint ---
// Protected by authMiddleware to ensure we're decoding a valid token.
app.get('/whoami', authMiddleware, (req, res) => {
  // The middleware already verified the token, so we can trust req.user
  return res.json({ decoded_and_verified_payload: req.user });
});

// --- Refresh Token Endpoint (FIXED VERSION) ---
app.post('/refresh', (req, res) => {
    const token = req.cookies.refreshToken;
    if (!token) return res.status(401).json({ error: 'No refresh token' });
  
    try {
      const payload = jwt.verify(token, REFRESH_SECRET, { algorithms: ['HS256'], issuer: TOKEN_ISSUER, audience: TOKEN_AUDIENCE });
      
      const info = refreshStore.get(payload.jti);
      if (!info || info.username !== payload.sub) {
          return res.status(401).json({ error: 'Invalid refresh token (may be revoked or reused)' });
      }
  
      DB.get("SELECT role FROM users WHERE username = ?", [payload.sub], (err, row) => {
          if (err || !row) {
              return res.status(401).json({ error: "User not found for refresh token" });
          }
  
          refreshStore.delete(payload.jti);
          
          const accessToken = jwt.sign(
              { sub: payload.sub, role: row.role },
              ACCESS_SECRET, 
              { expiresIn: '15m', issuer: TOKEN_ISSUER, audience: TOKEN_AUDIENCE }
          );

          const newRefreshTokenId = crypto.randomBytes(16).toString('hex');
          const newRefreshToken = jwt.sign(
            { sub: payload.sub, jti: newRefreshTokenId },
            REFRESH_SECRET,
            { expiresIn: '7d', issuer: TOKEN_ISSUER, audience: TOKEN_AUDIENCE }
          );
          refreshStore.set(newRefreshTokenId, { username: payload.sub });
  
          res.cookie('refreshToken', newRefreshToken, { httpOnly: true, secure: false, sameSite: 'Strict', maxAge: 7*24*60*60*1000 });
          res.json({ accessToken });
      });
  
    } catch (e) {
      return res.status(403).json({ error: 'Invalid or expired refresh token' });
    }
});

app.listen(PORT, () => console.log(`SECURE server running at http://localhost:${PORT}`));